import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/auth/presentation/pages/login_page.dart';
import '../../features/auth/presentation/pages/register_page.dart';
import '../../features/auth/presentation/pages/role_selection_page.dart';
import '../../features/auth/presentation/pages/forgot_password_page.dart';
import '../../features/auth/presentation/pages/reset_password_page.dart';
import '../../features/auth/presentation/pages/auth_callback_page.dart';
import '../../features/auth/presentation/pages/auth_error_page.dart';
import '../services/token_storage.dart';
import '../../features/individual/presentation/pages/individual_dashboard_page.dart';
import '../../features/individual/presentation/pages/individual_profile_page.dart';
import '../../features/individual/presentation/pages/individual_skill_tree_preview_page.dart';
import '../../features/individual/presentation/pages/individual_skill_tree_detail_page.dart';
import '../../features/individual/presentation/pages/individual_skill_tree_completion_page.dart';
import '../../features/individual/presentation/pages/individual_reports_page.dart';
import '../../features/individual/verification_flow/presentation/pages/individual_certificate_preview_page.dart';
import '../../features/individual/verification_flow/presentation/pages/individual_cost_breakdown_page.dart';
import '../../features/individual/verification_flow/presentation/pages/individual_verification_completion_page.dart';
import '../../features/individual/verification_flow/presentation/pages/individual_single_upload_page.dart';
import '../../features/individual/verification_flow/presentation/pages/individual_verification_checks_page.dart';
import '../../features/individual/verification_flow/presentation/pages/individual_verification_industry_page.dart';
import '../../features/individual/presentation/pages/individual_skill_tree_page.dart';
import '../../features/individual/presentation/pages/individual_sdc_page.dart';
import '../../features/individual/presentation/pages/individual_vault_page.dart';
import '../../features/individual/presentation/shell/app_shell_page.dart';
import '../../features/notifications/presentation/pages/notification_centre_page.dart';
import '../../features/onboarding/presentation/pages/splash_page.dart';
import '../../features/onboarding/presentation/pages/onboarding_page.dart';
import '../../features/orgs/presentation/pages/batch_progress_page.dart';
import '../../features/orgs/presentation/pages/all_batches_page.dart';
import '../../features/orgs/presentation/pages/org_credentials_page.dart';
import '../../features/orgs/presentation/pages/org_dashboard_page.dart';
import '../../features/orgs/presentation/pages/profile_settings_page.dart';
import '../../features/orgs/presentation/pages/registry_search_page.dart';
import '../../features/orgs/presentation/pages/verification_plan_builder_page.dart';
import '../../features/orgs/presentation/pages/verification_report_detail_page.dart';
import '../../features/orgs/presentation/pages/verification_reports_page.dart';
import '../../features/orgs/presentation/shell/org_shell_page.dart';
import '../../features/skills/presentation/pages/skill_tree_page.dart';
import '../../features/orgs/verification_flow/presentation/pages/batch_job_running_page.dart';
import '../../features/orgs/verification_flow/presentation/pages/batch_tracking_detail_page.dart';
import '../../features/orgs/verification_flow/presentation/pages/batch_created_success_page.dart';
import '../../features/orgs/verification_flow/presentation/pages/batch_type_selection_page.dart';
import '../../features/orgs/verification_flow/presentation/pages/bulk_upload_page.dart';
import '../../features/orgs/verification_flow/presentation/pages/certificate_preview_page.dart';
import '../../features/orgs/verification_flow/presentation/pages/credential_detail_page.dart';
import '../../features/orgs/verification_flow/presentation/pages/credential_template_selector_page.dart';
import '../../features/orgs/verification_flow/presentation/pages/credential_preview_approval_page.dart';
import '../../features/orgs/verification_flow/presentation/pages/credentials_approved_page.dart';
import '../../features/orgs/verification_flow/presentation/pages/credentials_generated_page.dart';
import '../../features/orgs/verification_flow/presentation/pages/individual_record_detail_page.dart';
import '../../features/orgs/verification_flow/presentation/pages/map_credential_fields_page.dart';
import '../../features/orgs/verification_flow/presentation/pages/organisation_registration_page.dart';
import '../../features/orgs/verification_flow/presentation/pages/otp_verification_page.dart';
import '../../features/orgs/verification_flow/presentation/pages/pending_approval_page.dart';
import '../../features/orgs/onboarding/presentation/pages/org_onboarding_page.dart';
import '../../features/orgs/verification_flow/presentation/pages/product_batch_created_page.dart';
import '../../features/orgs/verification_flow/presentation/pages/product_batch_setup_page.dart';
import '../../features/orgs/verification_flow/presentation/pages/product_bulk_upload_page.dart';
import '../../features/orgs/verification_flow/presentation/pages/product_sector_selector_page.dart';
import '../../features/orgs/verification_flow/presentation/pages/product_service_type_selector_page.dart';
import '../../features/orgs/verification_flow/presentation/pages/single_human_upload_page.dart';
import '../../features/orgs/verification_flow/presentation/pages/single_product_upload_page.dart';
import '../../features/orgs/verification_flow/presentation/pages/invite_created_success_page.dart';
import '../../features/orgs/verification_flow/presentation/pages/per_unit_cost_breakdown_page.dart';
import '../../features/orgs/verification_flow/presentation/pages/user_document_upload_page.dart';
import '../../features/orgs/verification_flow/presentation/pages/verification_plan_setup_page.dart';
import '../../features/orgs/verification_flow/presentation/pages/verification_checks_page.dart';
import '../../features/orgs/verification_flow/presentation/pages/verification_permissions_page.dart';
import '../../features/scanner/presentation/pages/qr_scanner_page.dart';
import '../../features/just_verifying/presentation/pages/public_verification_result_page.dart';
import '../../features/admin/presentation/pages/super_admin_dashboard_page.dart';
import '../../features/admin/presentation/pages/organisation_approval_detail_page.dart';
import '../../features/admin/presentation/pages/batch_monitoring_detail_page.dart';
import '../theme/app_colors.dart';
import '../theme/app_spacing.dart';
import '../theme/app_typography.dart';

class AppRouter {
  static const String splashPath = '/';
  static const String onboardingPath = '/onboarding';
  static const String roleSelectionPath = '/role-selection';
  static const String loginPath = '/login';
  static const String registerPath = '/register';
  static const String forgotPasswordPath = '/forgot-password';
  static const String resetPasswordPath = '/reset-password';
  static const String authCallbackPath = '/auth/callback';
  static const String authErrorPath = '/auth/error';

  static const String dashboardPath = '/app/dashboard';
  static const String walletPath = '/app/wallet';
  static const String qrScannerPath = '/app/qr-scan';
  static const String appBatchesPath = '/app/batches';
  static const String appBatchTrackingDetailPath = '/app/batches/tracking';
  static const String appIndividualRecordDetailPath = '/app/batches/record';
  static const String appCredentialDetailPath = '/app/batches/credential';
  static const String appRegistryPath = '/app/registry';
  static const String settingsPath = '/app/settings';
  static const String appReportsPath = '/app/reports';
  static const String appReportDetailPath = '/app/reports/detail';

  static const String notificationsPath = '/notifications';

  static const String verificationPlanBuilderPath =
      '/verification-plan-builder';
  static const String registrySearchPath = '/registry-search';
  static const String skillTreePath = '/skill-tree';
  static const String batchProgressPath = '/batch-progress';

  // Organisation auth flow
  static const String organisationRegistrationPath = '/org-registration';
  static const String otpVerificationPath = '/otp-verification';
  static const String pendingApprovalPath = '/pending-approval';
  static const String orgOnboardingPath = '/org-onboarding';

  // Organisation bulk verification flow
  static const String batchTypeSelectionPath = '/batch-type-selection';
  static const String verificationChecksPath = '/verification-checks';
  static const String verificationPermissionsPath = '/verification-permissions';
  static const String verificationPlanSetupPath = '/verification-plan-setup';
  static const String certificatePreviewPath = '/certificate-preview';
  static const String perUnitCostBreakdownPath = '/per-unit-cost-breakdown';
  static const String singleHumanUploadPath = '/single-human-upload';
  static const String singleProductUploadPath = '/single-product-upload';
  static const String inviteCreatedSuccessPath = '/invite-created-success';
  static const String credentialTemplateSelectorPath =
      '/credential-template-selector';
  static const String mapCredentialFieldsPath = '/map-credential-fields';
  static const String credentialPreviewApprovalPath =
      '/credential-preview-approval';
  static const String credentialsApprovedPath = '/credentials-approved';
  static const String batchJobRunningPath = '/batch-job-running';
  static const String bulkUploadPath = '/bulk-upload';
  static const String batchCreatedSuccessPath = '/batch-created-success';
  static const String productSectorSelectorPath = '/product-sector-selector';
  static const String productServiceTypeSelectorPath =
      '/product-service-type-selector';
  static const String productBatchSetupPath = '/product-batch-setup';
  static const String productBulkUploadPath = '/product-bulk-upload';
  static const String productBatchCreatedPath = '/product-batch-created';
  static const String userDocumentUploadPath = '/user-upload';
  static const String credentialsGeneratedPath = '/credentials-generated';
  static const String batchTrackingDetailPath = '/batch-tracking-detail';
  static const String individualRecordDetailPath = '/record-detail';
  static const String credentialDetailPath = '/credential-detail';

  // Public verification
  static const String publicVerificationResultPath =
      '/public-verification-result';

  // Individual
  static const String individualIdentityPath = '/me/identity';
  static const String individualScanPath = '/me/scan';
  static const String individualReportsPath = '/me/reports';
  static const String individualSdcPath = '/me/sdc';
  static const String individualVaultPath = '/me/vault';
  static const String individualProfilePath = '/me/profile';
  static const String individualSkillTreePreviewPath = '/me/skill-tree';
  static const String individualSkillTreeBuildPath = '/me/skill-tree/build';
  static const String individualSkillTreeDetailPath = '/me/skill-tree/detail';
  static const String individualSkillTreeCompletionPath =
      '/me/skill-tree/pending';
  static const String individualVerificationIndustryPath =
      '/me/verification/industry';
  static const String individualVerificationChecksPath =
      '/me/verification/checks';
  static const String individualVerificationUploadPath =
      '/me/verification/upload';
  static const String individualVerificationCertificatePreviewPath =
      '/me/verification/certificate-preview';
  static const String individualVerificationCostBreakdownPath =
      '/me/verification/cost-breakdown';
  static const String individualVerificationCompletionPath =
      '/me/verification/completion';

  // Admin
  static const String superAdminDashboardPath = '/admin/dashboard';
  static const String organisationApprovalDetailPath = '/admin/org-approval';
  static const String batchMonitoringDetailPath = '/admin/batch-monitoring';

  static final GoRouter router = GoRouter(
    initialLocation: splashPath,
    errorPageBuilder: (BuildContext context, GoRouterState state) {
      final Object? error = state.error;
      return _slideFadePage(
        state: state,
        child: Scaffold(
          backgroundColor: AppColors.pageBg,
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0,
            surfaceTintColor: Colors.transparent,
            title: const Text('Navigation Error'),
          ),
          body: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(AppSpacing.x4),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text('Route not found', style: AppTypography.display2),
                  const SizedBox(height: AppSpacing.x2),
                  Text(
                    'Location: ${state.uri}',
                    style: AppTypography.body2.copyWith(
                      color: AppColors.textSecondary,
                    ),
                  ),
                  const SizedBox(height: AppSpacing.x3),
                  Text(
                    error?.toString() ?? 'Unknown router error',
                    style: AppTypography.body2.copyWith(
                      color: AppColors.textSecondary,
                      height: 1.25,
                    ),
                  ),
                  const SizedBox(height: AppSpacing.x5),
                  ElevatedButton.icon(
                    onPressed: () => context.go(dashboardPath),
                    icon: const Icon(Icons.dashboard_rounded),
                    label: const Text('Back to Dashboard'),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    },
    redirect: (BuildContext context, GoRouterState state) async {
      final ProviderContainer container = ProviderScope.containerOf(context);
      final TokenStorage tokenStorage = container.read(tokenStorageProvider);
      final String? token = await tokenStorage.getToken();
      final bool isAuthenticated = token != null && token.trim().isNotEmpty;
      final String loginType =
          (await tokenStorage.getLoginType())?.trim().toLowerCase() ?? '';

      final bool forceAuthFlow =
          state.uri.queryParameters['force']?.toLowerCase() == 'true';
      if (forceAuthFlow &&
          (state.matchedLocation.startsWith(loginPath) ||
              state.matchedLocation.startsWith(registerPath))) {
        return null;
      }

      final bool isOnAuthPage =
          state.matchedLocation.startsWith(loginPath) ||
          state.matchedLocation.startsWith(registerPath) ||
          state.matchedLocation.startsWith(forgotPasswordPath) ||
          state.matchedLocation.startsWith(resetPasswordPath) ||
          state.matchedLocation.startsWith(authCallbackPath) ||
          state.matchedLocation.startsWith(authErrorPath) ||
          state.matchedLocation == splashPath ||
          state.matchedLocation.startsWith(onboardingPath) ||
          state.matchedLocation.startsWith(roleSelectionPath) ||
          state.matchedLocation.startsWith(organisationRegistrationPath) ||
          state.matchedLocation.startsWith(otpVerificationPath) ||
          state.matchedLocation.startsWith(pendingApprovalPath) ||
          state.matchedLocation.startsWith(publicVerificationResultPath) ||
          state.matchedLocation.startsWith(userDocumentUploadPath);

      if (!isAuthenticated && !isOnAuthPage) return loginPath;

      if (isAuthenticated &&
          loginType == 'individual' &&
          state.matchedLocation.startsWith('/app/')) {
        return individualIdentityPath;
      }

      if (isAuthenticated &&
          loginType.isNotEmpty &&
          loginType != 'individual' &&
          state.matchedLocation.startsWith('/me/')) {
        return dashboardPath;
      }

      if (isAuthenticated &&
          (state.matchedLocation == loginPath ||
              state.matchedLocation == registerPath)) {
        return loginType == 'individual'
            ? individualIdentityPath
            : dashboardPath;
      }
      return null;
    },
    routes: <RouteBase>[
      GoRoute(
        path: splashPath,
        name: 'splash',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(state: state, child: const SplashPage()),
      ),
      GoRoute(
        path: onboardingPath,
        name: 'onboarding',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(state: state, child: const OnboardingPage()),
      ),
      GoRoute(
        path: roleSelectionPath,
        name: 'role_selection',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(state: state, child: const RoleSelectionPage()),
      ),
      GoRoute(
        path: loginPath,
        name: 'login',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(state: state, child: const LoginPage()),
      ),
      GoRoute(
        path: registerPath,
        name: 'register',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(state: state, child: const RegisterPage()),
      ),
      GoRoute(
        path: forgotPasswordPath,
        name: 'forgot_password',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(state: state, child: const ForgotPasswordPage()),
      ),
      GoRoute(
        path: resetPasswordPath,
        name: 'reset_password',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(state: state, child: const ResetPasswordPage()),
      ),
      GoRoute(
        path: authCallbackPath,
        name: 'auth_callback',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(
              state: state,
              child: AuthCallbackPage(uri: state.uri),
            ),
      ),
      GoRoute(
        path: authErrorPath,
        name: 'auth_error',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(
              state: state,
              child: AuthErrorPage(
                message: state.uri.queryParameters['message'],
              ),
            ),
      ),
      GoRoute(
        path: individualVerificationCompletionPath,
        name: 'individual_verification_completion',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(
              state: state,
              child: const IndividualVerificationCompletionPage(),
            ),
      ),
      ShellRoute(
        builder: (BuildContext context, GoRouterState state, Widget child) =>
            OrgShellPage(child: child),
        routes: <RouteBase>[
          GoRoute(
            path: dashboardPath,
            name: 'dashboard',
            pageBuilder: (BuildContext context, GoRouterState state) =>
                _slideFadePage(state: state, child: const OrgDashboardPage()),
          ),
          GoRoute(
            path: appBatchesPath,
            name: 'batches',
            pageBuilder: (BuildContext context, GoRouterState state) =>
                _slideFadePage(state: state, child: const AllBatchesPage()),
          ),
          GoRoute(
            path: appBatchTrackingDetailPath,
            name: 'app_batch_tracking_detail',
            pageBuilder: (BuildContext context, GoRouterState state) =>
                _slideFadePage(
                  state: state,
                  child: const BatchTrackingDetailPage(),
                ),
          ),
          GoRoute(
            path: appIndividualRecordDetailPath,
            name: 'app_record_detail',
            pageBuilder: (BuildContext context, GoRouterState state) =>
                _slideFadePage(
                  state: state,
                  child: const IndividualRecordDetailPage(),
                ),
          ),
          GoRoute(
            path: appCredentialDetailPath,
            name: 'app_credential_detail',
            pageBuilder: (BuildContext context, GoRouterState state) =>
                _slideFadePage(
                  state: state,
                  child: const CredentialDetailPage(),
                ),
          ),
          GoRoute(
            path: appRegistryPath,
            name: 'registry',
            pageBuilder: (BuildContext context, GoRouterState state) =>
                _slideFadePage(state: state, child: const RegistrySearchPage()),
          ),
          GoRoute(
            path: walletPath,
            name: 'wallet',
            pageBuilder: (BuildContext context, GoRouterState state) =>
                _slideFadePage(state: state, child: const OrgCredentialsPage()),
          ),
          GoRoute(
            path: qrScannerPath,
            name: 'qr_scan',
            pageBuilder: (BuildContext context, GoRouterState state) =>
                _slideFadePage(state: state, child: const QRScannerPage()),
          ),
          GoRoute(
            path: settingsPath,
            name: 'settings',
            pageBuilder: (BuildContext context, GoRouterState state) =>
                _slideFadePage(
                  state: state,
                  child: const ProfileSettingsPage(),
                ),
          ),
          GoRoute(
            path: appReportsPath,
            name: 'app_reports',
            pageBuilder: (BuildContext context, GoRouterState state) =>
                _slideFadePage(
                  state: state,
                  child: const VerificationReportsPage(),
                ),
          ),
          GoRoute(
            path: appReportDetailPath,
            name: 'app_report_detail',
            pageBuilder: (BuildContext context, GoRouterState state) =>
                _slideFadePage(
                  state: state,
                  child: const VerificationReportDetailPage(),
                ),
          ),
        ],
      ),
      ShellRoute(
        builder: (BuildContext context, GoRouterState state, Widget child) =>
            IndividualShellPage(child: child),
        routes: <RouteBase>[
          GoRoute(
            path: individualIdentityPath,
            name: 'individual_identity',
            pageBuilder: (BuildContext context, GoRouterState state) =>
                _slideFadePage(
                  state: state,
                  child: const IndividualDashboardPage(),
                ),
          ),
          GoRoute(
            path: individualScanPath,
            name: 'individual_scan',
            pageBuilder: (BuildContext context, GoRouterState state) =>
                _slideFadePage(
                  state: state,
                  child: const IndividualSkillTreePreviewPage(),
                ),
          ),
          GoRoute(
            path: individualSkillTreeBuildPath,
            name: 'individual_skill_tree_build',
            pageBuilder: (BuildContext context, GoRouterState state) =>
                _slideFadePage(
                  state: state,
                  child: const IndividualSkillTreePage(),
                ),
          ),
          GoRoute(
            path: individualSkillTreeDetailPath,
            name: 'individual_skill_tree_detail',
            pageBuilder: (BuildContext context, GoRouterState state) =>
                _slideFadePage(
                  state: state,
                  child: const IndividualSkillTreeDetailPage(),
                ),
          ),
          GoRoute(
            path: individualSkillTreeCompletionPath,
            name: 'individual_skill_tree_completion',
            pageBuilder: (BuildContext context, GoRouterState state) =>
                _slideFadePage(
                  state: state,
                  child: const IndividualSkillTreeCompletionPage(),
                ),
          ),
          GoRoute(
            path: individualReportsPath,
            name: 'individual_reports',
            pageBuilder: (BuildContext context, GoRouterState state) =>
                _slideFadePage(
                  state: state,
                  child: const IndividualReportsPage(),
                ),
          ),
          GoRoute(
            path: individualSdcPath,
            name: 'individual_sdc',
            pageBuilder: (BuildContext context, GoRouterState state) =>
                _slideFadePage(
                  state: state,
                  child: const IndividualSdcPage(),
                ),
          ),
          GoRoute(
            path: individualVaultPath,
            name: 'individual_vault',
            pageBuilder: (BuildContext context, GoRouterState state) =>
                _slideFadePage(
                  state: state,
                  child: const IndividualVaultPage(),
                ),
          ),
          GoRoute(
            path: individualProfilePath,
            name: 'individual_profile',
            pageBuilder: (BuildContext context, GoRouterState state) =>
                _slideFadePage(
                  state: state,
                  child: const IndividualProfilePage(),
                ),
          ),
          GoRoute(
            path: individualVerificationIndustryPath,
            name: 'individual_verification_industry',
            pageBuilder: (BuildContext context, GoRouterState state) =>
                _slideFadePage(
                  state: state,
                  child: const IndividualVerificationIndustryPage(),
                ),
          ),
          GoRoute(
            path: individualVerificationChecksPath,
            name: 'individual_verification_checks',
            pageBuilder: (BuildContext context, GoRouterState state) =>
                _slideFadePage(
                  state: state,
                  child: const IndividualVerificationChecksPage(),
                ),
          ),
          GoRoute(
            path: individualVerificationUploadPath,
            name: 'individual_verification_upload',
            pageBuilder: (BuildContext context, GoRouterState state) =>
                _slideFadePage(
                  state: state,
                  child: const IndividualSingleUploadPage(),
                ),
          ),
          GoRoute(
            path: individualVerificationCertificatePreviewPath,
            name: 'individual_verification_certificate_preview',
            pageBuilder: (BuildContext context, GoRouterState state) =>
                _slideFadePage(
                  state: state,
                  child: const IndividualCertificatePreviewPage(),
                ),
          ),
          GoRoute(
            path: individualVerificationCostBreakdownPath,
            name: 'individual_verification_cost_breakdown',
            pageBuilder: (BuildContext context, GoRouterState state) =>
                _slideFadePage(
                  state: state,
                  child: const IndividualCostBreakdownPage(),
                ),
          ),
        ],
      ),
      GoRoute(
        path: notificationsPath,
        name: 'notifications',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(state: state, child: const NotificationCentrePage()),
      ),
      GoRoute(
        path: verificationPlanBuilderPath,
        name: 'verification_plan_builder',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(
              state: state,
              child: const VerificationPlanBuilderPage(),
            ),
      ),
      GoRoute(
        path: registrySearchPath,
        name: 'registry_search',
        redirect: (BuildContext context, GoRouterState state) {
          final String query = state.uri.hasQuery ? '?${state.uri.query}' : '';
          return '$appRegistryPath$query';
        },
      ),
      GoRoute(
        path: publicVerificationResultPath,
        name: 'public_verification_result',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(
              state: state,
              child: const PublicVerificationResultPage(),
            ),
      ),
      GoRoute(
        path: skillTreePath,
        name: 'skill_tree',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(state: state, child: const SkillTreePage()),
      ),
      GoRoute(
        path: batchProgressPath,
        name: 'batch_progress',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(state: state, child: const BatchProgressPage()),
      ),

      // Organisation auth flow
      GoRoute(
        path: organisationRegistrationPath,
        name: 'org_registration',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(
              state: state,
              child: const OrganisationRegistrationPage(),
            ),
      ),
      GoRoute(
        path: otpVerificationPath,
        name: 'otp_verification',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(state: state, child: const OtpVerificationPage()),
      ),
      GoRoute(
        path: pendingApprovalPath,
        name: 'pending_approval',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(state: state, child: const PendingApprovalPage()),
      ),
      GoRoute(
        path: orgOnboardingPath,
        name: 'org_onboarding',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(state: state, child: const OrgOnboardingPage()),
      ),

      // Organisation bulk verification flow
      GoRoute(
        path: batchTypeSelectionPath,
        name: 'batch_type_selection',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(state: state, child: const BatchTypeSelectionPage()),
      ),
      GoRoute(
        path: verificationChecksPath,
        name: 'verification_checks',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(state: state, child: const VerificationChecksPage()),
      ),
      GoRoute(
        path: verificationPermissionsPath,
        name: 'verification_permissions',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(
              state: state,
              child: const VerificationPermissionsPage(),
            ),
      ),
      GoRoute(
        path: productSectorSelectorPath,
        name: 'product_sector_selector',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(
              state: state,
              child: const ProductSectorSelectorPage(),
            ),
      ),
      GoRoute(
        path: productServiceTypeSelectorPath,
        name: 'product_service_type_selector',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(
              state: state,
              child: const ProductServiceTypeSelectorPage(),
            ),
      ),
      GoRoute(
        path: productBatchSetupPath,
        name: 'product_batch_setup',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(state: state, child: const ProductBatchSetupPage()),
      ),
      GoRoute(
        path: productBulkUploadPath,
        name: 'product_bulk_upload',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(state: state, child: const ProductBulkUploadPage()),
      ),
      GoRoute(
        path: productBatchCreatedPath,
        name: 'product_batch_created',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(
              state: state,
              child: const ProductBatchCreatedPage(),
            ),
      ),
      GoRoute(
        path: userDocumentUploadPath,
        name: 'user_document_upload',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(state: state, child: const UserDocumentUploadPage()),
      ),
      GoRoute(
        path: verificationPlanSetupPath,
        name: 'verification_plan_setup',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(
              state: state,
              child: const VerificationPlanSetupPage(),
            ),
      ),
      GoRoute(
        path: certificatePreviewPath,
        name: 'certificate_preview',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(state: state, child: const CertificatePreviewPage()),
      ),
      GoRoute(
        path: perUnitCostBreakdownPath,
        name: 'per_unit_cost_breakdown',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(
              state: state,
              child: const PerUnitCostBreakdownPage(),
            ),
      ),
      GoRoute(
        path: singleHumanUploadPath,
        name: 'single_human_upload',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(state: state, child: const SingleHumanUploadPage()),
      ),
      GoRoute(
        path: singleProductUploadPath,
        name: 'single_product_upload',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(
              state: state,
              child: const SingleProductUploadPage(),
            ),
      ),
      GoRoute(
        path: inviteCreatedSuccessPath,
        name: 'invite_created_success',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(
              state: state,
              child: const InviteCreatedSuccessPage(),
            ),
      ),
      GoRoute(
        path: credentialTemplateSelectorPath,
        name: 'credential_template_selector',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(
              state: state,
              child: const CredentialTemplateSelectorPage(),
            ),
      ),
      GoRoute(
        path: mapCredentialFieldsPath,
        name: 'map_credential_fields',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(
              state: state,
              child: const MapCredentialFieldsPage(),
            ),
      ),
      GoRoute(
        path: credentialPreviewApprovalPath,
        name: 'credential_preview_approval',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(
              state: state,
              child: const CredentialPreviewApprovalPage(),
            ),
      ),
      GoRoute(
        path: credentialsApprovedPath,
        name: 'credentials_approved',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(
              state: state,
              child: const CredentialsApprovedPage(),
            ),
      ),
      GoRoute(
        path: batchJobRunningPath,
        name: 'batch_job_running',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(state: state, child: const BatchJobRunningPage()),
      ),
      GoRoute(
        path: bulkUploadPath,
        name: 'bulk_upload',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(state: state, child: const BulkUploadPage()),
      ),
      GoRoute(
        path: batchCreatedSuccessPath,
        name: 'batch_created_success',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(
              state: state,
              child: const BatchCreatedSuccessPage(),
            ),
      ),
      GoRoute(
        path: credentialsGeneratedPath,
        name: 'credentials_generated',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(
              state: state,
              child: const CredentialsGeneratedPage(),
            ),
      ),
      GoRoute(
        path: batchTrackingDetailPath,
        name: 'batch_tracking_detail',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(
              state: state,
              child: const BatchTrackingDetailPage(),
            ),
      ),
      GoRoute(
        path: individualRecordDetailPath,
        name: 'individual_record_detail',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(
              state: state,
              child: const IndividualRecordDetailPage(),
            ),
      ),
      GoRoute(
        path: credentialDetailPath,
        name: 'credential_detail',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(state: state, child: const CredentialDetailPage()),
      ),

      // Admin
      GoRoute(
        path: superAdminDashboardPath,
        name: 'admin_dashboard',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(
              state: state,
              child: const SuperAdminDashboardPage(),
            ),
      ),
      GoRoute(
        path: organisationApprovalDetailPath,
        name: 'org_approval_detail',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(
              state: state,
              child: const OrganisationApprovalDetailPage(),
            ),
      ),
      GoRoute(
        path: batchMonitoringDetailPath,
        name: 'batch_monitoring_detail',
        pageBuilder: (BuildContext context, GoRouterState state) =>
            _slideFadePage(
              state: state,
              child: const BatchMonitoringDetailPage(),
            ),
      ),
    ],
  );

  static CustomTransitionPage<void> _slideFadePage({
    required GoRouterState state,
    required Widget child,
  }) {
    return CustomTransitionPage<void>(
      key: state.pageKey,
      child: child,
      transitionDuration: const Duration(milliseconds: 260),
      reverseTransitionDuration: const Duration(milliseconds: 220),
      transitionsBuilder:
          (
            BuildContext context,
            Animation<double> animation,
            Animation<double> secondaryAnimation,
            Widget child,
          ) {
            final Animation<Offset> slideAnim =
                Tween<Offset>(
                  begin: const Offset(0.04, 0),
                  end: Offset.zero,
                ).animate(
                  CurvedAnimation(
                    parent: animation,
                    curve: Curves.easeOutCubic,
                  ),
                );
            final Animation<double> fadeAnim =
                Tween<double>(begin: 0.0, end: 1.0).animate(
                  CurvedAnimation(parent: animation, curve: Curves.easeOut),
                );
            return FadeTransition(
              opacity: fadeAnim,
              child: SlideTransition(position: slideAnim, child: child),
            );
          },
    );
  }
}
