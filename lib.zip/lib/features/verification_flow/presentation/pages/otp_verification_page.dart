import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/router/app_router.dart';
import '../../../../core/theme/app_spacing.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/tmz_button.dart';

class OtpVerificationPage extends StatelessWidget {
  const OtpVerificationPage({super.key});

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: <Widget>[
            SvgPicture.asset(
              'assets/icons/trumarkz_shield.svg',
              height: 22,
              colorFilter: ColorFilter.mode(scheme.primary, BlendMode.srcIn),
            ),
            const SizedBox(width: AppSpacing.x2),
            const Text('OTP Verification'),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(AppSpacing.x4),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Text('Verify OTP', style: AppTypography.display2),
            const SizedBox(height: AppSpacing.x2),
            Text(
              'Enter the 6-digit code sent to your mobile.',
              style: AppTypography.body2.copyWith(
                color: scheme.onSurface.withAlpha(160),
              ),
            ),
            const SizedBox(height: AppSpacing.x6),
            TextField(
              keyboardType: TextInputType.number,
              textAlign: TextAlign.center,
              style: AppTypography.display2,
              maxLength: 6,
              decoration: const InputDecoration(counterText: ''),
            ),
            const Spacer(),
            TMZButton(
              label: 'Verify',
              onPressed: () => context.go(AppRouter.pendingApprovalPath),
            ),
          ],
        ),
      ),
    );
  }
}

