import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/router/app_router.dart';
import '../../../../core/theme/app_spacing.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/tmz_button.dart';
import '../../../../core/widgets/tmz_input.dart';

class OrganisationRegistrationPage extends StatelessWidget {
  const OrganisationRegistrationPage({super.key});

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: <Widget>[
            SvgPicture.asset(
              'assets/icons/trumarkz_shield.svg',
              height: 22,
              colorFilter: ColorFilter.mode(scheme.primary, BlendMode.srcIn),
            ),
            const SizedBox(width: AppSpacing.x2),
            const Text('Organisation Registration'),
          ],
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(AppSpacing.x4),
        children: <Widget>[
          Text('Create organisation', style: AppTypography.display2),
          const SizedBox(height: AppSpacing.x2),
          Text(
            'Register your organisation to run bulk verification.',
            style: AppTypography.body2.copyWith(
              color: scheme.onSurface.withAlpha(160),
            ),
          ),
          const SizedBox(height: AppSpacing.x6),
          const TMZInput(label: 'Organisation name', hintText: 'Acme Corp'),
          const SizedBox(height: AppSpacing.x4),
          const TMZInput(label: 'Admin email', hintText: 'admin@acme.com'),
          const SizedBox(height: AppSpacing.x4),
          const TMZInput(
            label: 'Mobile number',
            hintText: '+91 98765 43210',
            keyboardType: TextInputType.phone,
          ),
          const SizedBox(height: AppSpacing.x6),
          TMZButton(
            label: 'Send OTP',
            onPressed: () => context.go(AppRouter.otpVerificationPath),
          ),
        ],
      ),
    );
  }
}

