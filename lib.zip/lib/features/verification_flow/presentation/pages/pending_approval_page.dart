import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/router/app_router.dart';
import '../../../../core/theme/app_spacing.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/tmz_button.dart';
import '../../../../core/widgets/tmz_card.dart';

class PendingApprovalPage extends StatefulWidget {
  const PendingApprovalPage({super.key});

  @override
  State<PendingApprovalPage> createState() => _PendingApprovalPageState();
}

class _PendingApprovalPageState extends State<PendingApprovalPage> {
  Timer? _timer;
  bool _approved = false;

  @override
  void initState() {
    super.initState();
    _timer = Timer(const Duration(seconds: 2), () {
      if (!mounted) return;
      setState(() => _approved = true);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: <Widget>[
            SvgPicture.asset(
              'assets/icons/trumarkz_shield.svg',
              height: 22,
              colorFilter: ColorFilter.mode(scheme.primary, BlendMode.srcIn),
            ),
            const SizedBox(width: AppSpacing.x2),
            const Text('Pending Approval'),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(AppSpacing.x4),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Text('Organisation status', style: AppTypography.display2),
            const SizedBox(height: AppSpacing.x4),
            TMZCard(
              child: Row(
                children: <Widget>[
                  Icon(
                    _approved ? Icons.verified_rounded : Icons.hourglass_bottom,
                    color: _approved ? Colors.green : scheme.primary,
                  ),
                  const SizedBox(width: AppSpacing.x3),
                  Expanded(
                    child: Text(
                      _approved
                          ? 'Approved! You can access your dashboard.'
                          : 'Awaiting approval from TruMarkZ admin.',
                      style: AppTypography.body1,
                    ),
                  ),
                ],
              ),
            ),
            const Spacer(),
            TMZButton(
              label: _approved ? 'Go to Dashboard' : 'Waiting...',
              onPressed:
                  _approved ? () => context.go(AppRouter.dashboardPath) : null,
            ),
          ],
        ),
      ),
    );
  }
}

