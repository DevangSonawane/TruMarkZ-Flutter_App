import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/router/app_router.dart';
import '../../../../core/theme/app_spacing.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/tmz_button.dart';

enum _Role { organisation, individual, verifying }

class RoleSelectionPage extends StatefulWidget {
  const RoleSelectionPage({super.key});

  @override
  State<RoleSelectionPage> createState() => _RoleSelectionPageState();
}

class _RoleSelectionPageState extends State<RoleSelectionPage> {
  _Role? _selected;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        titleSpacing: 12,
        title: Row(
          children: <Widget>[
            SvgPicture.asset(
              'assets/icons/trumarkz_shield.svg',
              height: 18,
              colorFilter: ColorFilter.mode(scheme.primary, BlendMode.srcIn),
            ),
            const SizedBox(width: AppSpacing.x2),
            Text('TruMarkZ', style: AppTypography.heading2),
          ],
        ),
        actions: <Widget>[
          IconButton(
            icon: const Icon(Icons.notifications_none_rounded),
            onPressed: () => context.go(AppRouter.notificationsPath),
          ),
        ],
      ),
      body: SafeArea(
        child: Stack(
          children: <Widget>[
            ListView(
              padding: const EdgeInsets.fromLTRB(
                AppSpacing.x4,
                AppSpacing.x6,
                AppSpacing.x4,
                120,
              ),
              children: <Widget>[
                Text(
                  'How will you use\nTruMarkZ?',
                  textAlign: TextAlign.center,
                  style: AppTypography.display2.copyWith(fontSize: 28),
                ),
                const SizedBox(height: AppSpacing.x2),
                Text(
                  'You can always switch later',
                  textAlign: TextAlign.center,
                  style: AppTypography.body2.copyWith(
                    color: scheme.onSurface.withAlpha(150),
                  ),
                ),
                const SizedBox(height: AppSpacing.x6),
                _RoleOptionCard(
                  selected: _selected == _Role.organisation,
                  title: 'Organisation\n/ Business',
                  subtitle: 'Verify workers, products\n& services in bulk',
                  icon: Icons.business_center_rounded,
                  onTap: () => setState(() => _selected = _Role.organisation),
                ),
                const SizedBox(height: AppSpacing.x3),
                _RoleOptionCard(
                  selected: _selected == _Role.individual,
                  title: 'Individual',
                  subtitle: 'Build your verified Skill\nTree & digital credentials',
                  icon: Icons.person_outline_rounded,
                  onTap: () => setState(() => _selected = _Role.individual),
                ),
                const SizedBox(height: AppSpacing.x3),
                _RoleOptionCard(
                  selected: _selected == _Role.verifying,
                  title: 'Just\nVerifying',
                  subtitle: 'Scan a QR code or\nsearch the registry',
                  icon: Icons.qr_code_scanner_rounded,
                  onTap: () => setState(() => _selected = _Role.verifying),
                ),
              ],
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(
                    AppSpacing.x4,
                    AppSpacing.x2,
                    AppSpacing.x4,
                    AppSpacing.x4,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      SizedBox(
                        width: 56,
                        child: Divider(
                          height: 14,
                          thickness: 2,
                          color: scheme.primary,
                        ),
                      ),
                      TMZButton(
                        label: 'CONTINUE',
                        onPressed: _selected == null
                            ? null
                            : () {
                                switch (_selected!) {
                                  case _Role.organisation:
                                    context.go(AppRouter.organisationRegistrationPath);
                                  case _Role.individual:
                                    context.go(AppRouter.skillTreePath);
                                  case _Role.verifying:
                                    context.go(AppRouter.registrySearchPath);
                                }
                              },
                      ),
                      const SizedBox(height: AppSpacing.x2),
                      Row(
                        children: <Widget>[
                          Text(
                            'ENCRYPT',
                            style: AppTypography.caption.copyWith(
                              letterSpacing: 1.6,
                              color: scheme.onSurface.withAlpha(120),
                            ),
                          ),
                          const Spacer(),
                          Text(
                            'ROLE',
                            style: AppTypography.caption.copyWith(
                              letterSpacing: 1.6,
                              color: scheme.onSurface.withAlpha(120),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RoleOptionCard extends StatelessWidget {
  const _RoleOptionCard({
    required this.selected,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.onTap,
  });

  final bool selected;
  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    final Color borderColor = selected
        ? scheme.primary.withAlpha(120)
        : scheme.outlineVariant;

    return Material(
      color: scheme.surface,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.all(AppSpacing.x4),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: borderColor),
            boxShadow: <BoxShadow>[
              BoxShadow(
                color: Colors.black.withAlpha(10),
                blurRadius: 18,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: Row(
            children: <Widget>[
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: scheme.primary.withAlpha(22),
                  borderRadius: BorderRadius.circular(12),
                ),
                alignment: Alignment.center,
                child: Icon(icon, color: scheme.primary),
              ),
              const SizedBox(width: AppSpacing.x3),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(title, style: AppTypography.heading1),
                    const SizedBox(height: AppSpacing.x1),
                    Text(
                      subtitle,
                      style: AppTypography.body2.copyWith(
                        color: scheme.onSurface.withAlpha(150),
                      ),
                    ),
                  ],
                ),
              ),
              Icon(Icons.chevron_right_rounded, color: scheme.outline),
            ],
          ),
        ),
      ),
    );
  }
}
