import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/router/app_router.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_spacing.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/tmz_button.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> with TickerProviderStateMixin {
  late final TabController _tabController;
  bool _agree = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this, initialIndex: 0);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        titleSpacing: 12,
        title: Row(
          children: <Widget>[
            SvgPicture.asset(
              'assets/icons/trumarkz_shield.svg',
              height: 18,
              colorFilter: ColorFilter.mode(scheme.primary, BlendMode.srcIn),
            ),
            const SizedBox(width: AppSpacing.x2),
            Text('TruMarkZ', style: AppTypography.heading2),
          ],
        ),
        actions: <Widget>[
          const CircleAvatar(
            radius: 14,
            backgroundColor: AppColors.silverGray,
            child: Icon(Icons.person, size: 16, color: AppColors.darkNavy),
          ),
          const SizedBox(width: AppSpacing.x3),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(AppSpacing.x4),
          children: <Widget>[
            _AuthCard(
              tabController: _tabController,
              agree: _agree,
              onAgreeChanged: (bool value) => setState(() => _agree = value),
            ),
            const SizedBox(height: AppSpacing.x4),
            Text(
              '© 2024 TruMarkZ. All rights reserved.',
              textAlign: TextAlign.center,
              style: AppTypography.caption.copyWith(
                color: scheme.onSurface.withAlpha(140),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _AuthCard extends StatelessWidget {
  const _AuthCard({
    required this.tabController,
    required this.agree,
    required this.onAgreeChanged,
  });

  final TabController tabController;
  final bool agree;
  final ValueChanged<bool> onAgreeChanged;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;

    return Container(
      decoration: BoxDecoration(
        color: scheme.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: scheme.outlineVariant),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: Colors.black.withAlpha(8),
            blurRadius: 24,
            offset: const Offset(0, 14),
          ),
        ],
      ),
      padding: const EdgeInsets.all(AppSpacing.x4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          _PillTabs(controller: tabController),
          const SizedBox(height: AppSpacing.x4),
          AnimatedSize(
            duration: const Duration(milliseconds: 220),
            curve: Curves.easeOut,
            alignment: Alignment.topCenter,
            child: AnimatedBuilder(
              animation: tabController,
              builder: (BuildContext context, _) {
                final int index = tabController.index;
                return AnimatedSwitcher(
                  duration: const Duration(milliseconds: 180),
                  switchInCurve: Curves.easeOut,
                  switchOutCurve: Curves.easeIn,
                  child: index == 0
                      ? _RegisterForm(
                          key: const ValueKey<String>('register'),
                          agree: agree,
                          onAgreeChanged: onAgreeChanged,
                        )
                      : const _LoginForm(key: ValueKey<String>('login')),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _PillTabs extends StatelessWidget {
  const _PillTabs({required this.controller});

  final TabController controller;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;

    return Container(
      height: 44,
      decoration: BoxDecoration(
        color: scheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(12),
      ),
      child: TabBar(
        controller: controller,
        labelStyle: AppTypography.label.copyWith(letterSpacing: 0.2),
        unselectedLabelColor: scheme.onSurface.withAlpha(140),
        labelColor: scheme.onSurface,
        indicator: BoxDecoration(
          color: scheme.surface,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: scheme.outlineVariant),
        ),
        dividerColor: Colors.transparent,
        tabs: const <Widget>[
          Tab(text: 'Register'),
          Tab(text: 'Login'),
        ],
      ),
    );
  }
}

class _RegisterForm extends StatelessWidget {
  const _RegisterForm({
    super.key,
    required this.agree,
    required this.onAgreeChanged,
  });

  final bool agree;
  final ValueChanged<bool> onAgreeChanged;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;

    Widget label(String value) => Text(
          value.toUpperCase(),
          style: AppTypography.caption.copyWith(
            fontWeight: FontWeight.w700,
            letterSpacing: 0.6,
            color: scheme.onSurface.withAlpha(140),
          ),
        );

    InputDecoration decoration({
      required String hint,
      IconData? icon,
      Widget? suffix,
    }) {
      return InputDecoration(
        hintText: hint,
        prefixIcon: icon == null ? null : Icon(icon),
        suffixIcon: suffix,
        filled: true,
        fillColor: scheme.surface,
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: scheme.outlineVariant),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: scheme.outlineVariant),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: AppColors.brandBlue, width: 1.5),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text('Create your account', style: AppTypography.heading1),
        const SizedBox(height: AppSpacing.x2),
        Text(
          'Join the secure TruMarkZ network today.',
          style: AppTypography.body2.copyWith(color: scheme.onSurface.withAlpha(160)),
        ),
        const SizedBox(height: AppSpacing.x4),
        label('Full name'),
        const SizedBox(height: AppSpacing.x1),
        TextField(
          decoration: decoration(hint: 'John Doe', icon: Icons.person_outline_rounded),
        ),
        const SizedBox(height: AppSpacing.x3),
        label('Business email'),
        const SizedBox(height: AppSpacing.x1),
        TextField(
          keyboardType: TextInputType.emailAddress,
          decoration:
              decoration(hint: 'john@company.com', icon: Icons.mail_outline_rounded),
        ),
        const SizedBox(height: AppSpacing.x3),
        label('Verification code'),
        const SizedBox(height: AppSpacing.x1),
        TextField(
          keyboardType: TextInputType.number,
          decoration: decoration(
            hint: 'Enter 6 - digit OTP',
            icon: Icons.verified_outlined,
            suffix: TextButton(
              onPressed: () {},
              child: const Text('Get Code'),
            ),
          ),
        ),
        const SizedBox(height: AppSpacing.x3),
        label('Organization'),
        const SizedBox(height: AppSpacing.x1),
        DropdownButtonFormField<String>(
          initialValue: null,
          items: const <DropdownMenuItem<String>>[
            DropdownMenuItem(value: 'legal', child: Text('Legal Entity')),
            DropdownMenuItem(value: 'ngo', child: Text('NGO')),
            DropdownMenuItem(value: 'edu', child: Text('Education')),
          ],
          onChanged: (_) {},
          decoration: decoration(hint: 'Select Legal Entity Type', icon: Icons.apartment),
        ),
        const SizedBox(height: AppSpacing.x2),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Checkbox(
              value: agree,
              onChanged: (bool? v) => onAgreeChanged(v ?? false),
              activeColor: AppColors.brandBlue,
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Text(
                  'I agree to the Terms of Service and Privacy Policy.',
                  style: AppTypography.caption.copyWith(
                    color: scheme.onSurface.withAlpha(160),
                  ),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: AppSpacing.x2),
        TMZButton(
          label: 'Create Account',
          onPressed: agree ? () => context.go(AppRouter.roleSelectionPath) : null,
        ),
        const SizedBox(height: AppSpacing.x4),
        Center(
          child: Text(
            'OR REGISTER WITH',
            style: AppTypography.caption.copyWith(
              fontWeight: FontWeight.w700,
              letterSpacing: 1.2,
              color: scheme.onSurface.withAlpha(120),
            ),
          ),
        ),
        const SizedBox(height: AppSpacing.x2),
        Row(
          children: <Widget>[
            Expanded(
              child: OutlinedButton.icon(
                onPressed: () {},
                icon: const Icon(Icons.g_mobiledata_rounded),
                label: const Text('Google'),
              ),
            ),
            const SizedBox(width: AppSpacing.x3),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: () {},
                icon: const Icon(Icons.work_rounded),
                label: const Text('LinkedIn'),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _LoginForm extends StatelessWidget {
  const _LoginForm({super.key});

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;

    InputDecoration decoration({required String hint, IconData? icon}) {
      return InputDecoration(
        hintText: hint,
        prefixIcon: icon == null ? null : Icon(icon),
        filled: true,
        fillColor: scheme.surface,
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: scheme.outlineVariant),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: scheme.outlineVariant),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: AppColors.brandBlue, width: 1.5),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text('Welcome back', style: AppTypography.heading1),
        const SizedBox(height: AppSpacing.x2),
        Text(
          'Sign in to continue.',
          style: AppTypography.body2.copyWith(color: scheme.onSurface.withAlpha(160)),
        ),
        const SizedBox(height: AppSpacing.x4),
        TextField(
          keyboardType: TextInputType.emailAddress,
          decoration: decoration(hint: 'john@company.com', icon: Icons.mail_outline_rounded),
        ),
        const SizedBox(height: AppSpacing.x3),
        TextField(
          obscureText: true,
          decoration: decoration(hint: 'Password', icon: Icons.lock_outline_rounded),
        ),
        const SizedBox(height: AppSpacing.x4),
        TMZButton(
          label: 'Continue',
          onPressed: () => context.go(AppRouter.dashboardPath),
        ),
      ],
    );
  }
}
