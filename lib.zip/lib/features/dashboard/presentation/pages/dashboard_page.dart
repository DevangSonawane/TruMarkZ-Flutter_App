import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/router/app_router.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_spacing.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/tmz_button.dart';
import '../../../../core/widgets/tmz_card.dart';

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    final bool isDark = Theme.of(context).brightness == Brightness.dark;
    final Color surface = isDark ? AppColors.surfaceDark : scheme.surface;

    return Scaffold(
      appBar: AppBar(
        titleSpacing: 12,
        title: Row(
          children: <Widget>[
            SvgPicture.asset(
              'assets/icons/trumarkz_shield.svg',
              height: 18,
              colorFilter: ColorFilter.mode(scheme.primary, BlendMode.srcIn),
            ),
            const SizedBox(width: AppSpacing.x2),
            const Text('TruMarkZ'),
          ],
        ),
        actions: <Widget>[
          const CircleAvatar(
            radius: 14,
            backgroundColor: AppColors.silverGray,
            child: Icon(Icons.person, size: 16, color: AppColors.darkNavy),
          ),
          const SizedBox(width: AppSpacing.x3),
        ],
      ),
      body: CustomScrollView(
        slivers: <Widget>[
          SliverPadding(
            padding: const EdgeInsets.all(AppSpacing.x4),
            sliver: SliverList(
              delegate: SliverChildListDelegate(
                <Widget>[
                  _WelcomeCard(
                    onNewBatch: () => context.go(AppRouter.verificationPlanSetupPath),
                  ),
                  const SizedBox(height: AppSpacing.x4),
                  Text('Key Metrics', style: AppTypography.heading1),
                  const SizedBox(height: AppSpacing.x3),
                  GridView.count(
                    crossAxisCount: 2,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    mainAxisSpacing: AppSpacing.x3,
                    crossAxisSpacing: AppSpacing.x3,
                    childAspectRatio: 1.55,
                    children: const <Widget>[
                      _MetricCard(title: '12,842', subtitle: 'Total Credentials'),
                      _MetricCard(title: '99.99%', subtitle: 'Compliance'),
                      _MetricCard(title: '24', subtitle: 'Active Batches'),
                      _MetricCard(title: '1.2s', subtitle: 'Avg Processing'),
                    ],
                  ),
                  const SizedBox(height: AppSpacing.x6),
                  Text('Recent Batch\nActivity', style: AppTypography.heading1),
                  const SizedBox(height: AppSpacing.x3),
                  TMZCard(
                    onTap: () => context.push(AppRouter.batchTrackingDetailPath),
                    child: const ListTile(
                      leading: Icon(Icons.local_activity_outlined),
                      title: Text('Acme Corp'),
                      subtitle: Text('Batch #A1C3 • 24/80'),
                      trailing: Icon(Icons.chevron_right_rounded),
                    ),
                  ),
                  const SizedBox(height: AppSpacing.x2),
                  TMZCard(
                    onTap: () => context.push(AppRouter.batchTrackingDetailPath),
                    child: const ListTile(
                      leading: Icon(Icons.local_activity_outlined),
                      title: Text('BlueBank'),
                      subtitle: Text('Batch #B2D9 • Completed'),
                      trailing: Icon(Icons.chevron_right_rounded),
                    ),
                  ),
                  const SizedBox(height: AppSpacing.x6),
                  Text('LIVE NETWORK FEED', style: AppTypography.label),
                  const SizedBox(height: AppSpacing.x2),
                  Container(
                    decoration: BoxDecoration(
                      color: surface,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: scheme.outlineVariant),
                    ),
                    padding: const EdgeInsets.all(AppSpacing.x4),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text('Network status', style: AppTypography.heading2),
                        const SizedBox(height: AppSpacing.x2),
                        Text(
                          'All systems operational.\nLast block: 19,288,321',
                          style: AppTypography.body2.copyWith(
                            color: scheme.onSurface.withAlpha(170),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: AppSpacing.x12),
                ],
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => context.go(AppRouter.verificationPlanSetupPath),
        child: const Icon(Icons.add_rounded),
      ),
    );
  }
}

class _WelcomeCard extends StatelessWidget {
  const _WelcomeCard({required this.onNewBatch});

  final VoidCallback onNewBatch;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    final bool isDark = Theme.of(context).brightness == Brightness.dark;
    final Color base = isDark ? AppColors.surfaceDark : scheme.surface;

    return Container(
      decoration: BoxDecoration(
        color: base,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: scheme.outlineVariant),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: Colors.black.withAlpha(isDark ? 20 : 8),
            blurRadius: 26,
            offset: const Offset(0, 16),
          ),
        ],
      ),
      padding: const EdgeInsets.all(AppSpacing.x4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text('Welcome\nback, Apex\nLogistics', style: AppTypography.display2),
          const SizedBox(height: AppSpacing.x2),
          Text(
            'Your verification operations\nare running smoothly. Ready\nfor the next batch?',
            style: AppTypography.body2.copyWith(
              color: scheme.onSurface.withAlpha(160),
            ),
          ),
          const SizedBox(height: AppSpacing.x4),
          Align(
            alignment: Alignment.centerLeft,
            child: TMZButton(
              label: 'NEW BATCH',
              fullWidth: false,
              onPressed: onNewBatch,
            ),
          ),
        ],
      ),
    );
  }
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({required this.title, required this.subtitle});

  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    final bool isDark = Theme.of(context).brightness == Brightness.dark;
    final Color base = isDark ? AppColors.surfaceDark : scheme.surface;

    return Container(
      decoration: BoxDecoration(
        color: base,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: scheme.outlineVariant),
      ),
      padding: const EdgeInsets.all(AppSpacing.x4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(title, style: AppTypography.heading1),
          const SizedBox(height: AppSpacing.x1),
          Text(
            subtitle,
            style: AppTypography.caption.copyWith(
              color: scheme.onSurface.withAlpha(160),
            ),
          ),
        ],
      ),
    );
  }
}
