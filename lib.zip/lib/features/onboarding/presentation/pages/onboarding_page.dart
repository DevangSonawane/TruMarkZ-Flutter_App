import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/router/app_router.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_spacing.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/tmz_button.dart';

class OnboardingPage extends StatelessWidget {
  const OnboardingPage({super.key});

  @override
  Widget build(BuildContext context) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;
    final ColorScheme scheme = Theme.of(context).colorScheme;
    final Color bgTop = isDark ? const Color(0xFF050A14) : const Color(0xFFF3F6FF);
    final Color bgBottom = isDark ? AppColors.darkNavy : Colors.white;

    return Scaffold(
      backgroundColor: bgBottom,
      appBar: AppBar(
        title: Row(
          children: <Widget>[
            SvgPicture.asset(
              'assets/icons/trumarkz_shield.svg',
              height: 18,
              colorFilter: ColorFilter.mode(scheme.primary, BlendMode.srcIn),
            ),
            const SizedBox(width: AppSpacing.x2),
            Text('TruMarkZ', style: AppTypography.heading2),
          ],
        ),
      ),
      body: SafeArea(
        child: Stack(
          children: <Widget>[
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: <Color>[bgTop, bgBottom],
                  ),
                ),
              ),
            ),
            ListView(
              padding: const EdgeInsets.fromLTRB(
                AppSpacing.x4,
                AppSpacing.x10,
                AppSpacing.x4,
                AppSpacing.x6,
              ),
              children: <Widget>[
                Center(
                  child: Container(
                    width: 92,
                    height: 92,
                    decoration: BoxDecoration(
                      color: isDark
                          ? Colors.white.withAlpha(24)
                          : scheme.primary.withAlpha(18),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color:
                            isDark ? Colors.white.withAlpha(28) : scheme.outlineVariant,
                      ),
                    ),
                    alignment: Alignment.center,
                    child: SvgPicture.asset(
                      'assets/icons/trumarkz_shield.svg',
                      height: 34,
                      colorFilter: ColorFilter.mode(
                        isDark ? Colors.white : scheme.primary,
                        BlendMode.srcIn,
                      ),
                    ),
                  ),
                )
                    .animate()
                    .fadeIn(duration: 260.ms)
                    .scale(begin: const Offset(0.92, 0.92), end: const Offset(1, 1)),
                const SizedBox(height: AppSpacing.x4),
                Text(
                  'TruMarkZ',
                  textAlign: TextAlign.center,
                  style: AppTypography.display2.copyWith(
                    fontSize: 34,
                    color: isDark ? Colors.white : scheme.onSurface,
                  ),
                ).animate().fadeIn(delay: 60.ms, duration: 240.ms),
                const SizedBox(height: AppSpacing.x2),
                Text(
                  'VERIFY · TRUST ·\nTRANSFORM',
                  textAlign: TextAlign.center,
                  style: AppTypography.label.copyWith(
                    color: (isDark ? Colors.white : scheme.onSurface).withAlpha(180),
                  ),
                ).animate().fadeIn(delay: 120.ms, duration: 240.ms),
                const SizedBox(height: AppSpacing.x4),
                _TagPill(
                  icon: Icons.link_rounded,
                  label: 'BLOCKCHAIN-BACKED',
                  dark: isDark,
                ).animate().fadeIn(delay: 160.ms, duration: 220.ms),
                const SizedBox(height: AppSpacing.x2),
                _TagPill(
                  icon: Icons.verified_rounded,
                  label: 'GOV. API VERIFIED',
                  dark: isDark,
                ).animate().fadeIn(delay: 200.ms, duration: 220.ms),
                const SizedBox(height: AppSpacing.x2),
                _TagPill(
                  icon: Icons.shield_rounded,
                  label: 'TAMPER-PROOF',
                  dark: isDark,
                ).animate().fadeIn(delay: 240.ms, duration: 220.ms),
                const SizedBox(height: AppSpacing.x6),
                TMZButton(
                  label: 'Get Started',
                  onPressed: () => context.go(AppRouter.loginPath),
                ),
                const SizedBox(height: AppSpacing.x2),
                TMZButton(
                  label: isDark ? 'I Already Have an Account' : 'Sign In',
                  variant: TMZButtonVariant.secondary,
                  onPressed: () => context.go(AppRouter.loginPath),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _TagPill extends StatelessWidget {
  const _TagPill({required this.icon, required this.label, required this.dark});

  final IconData icon;
  final String label;
  final bool dark;

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    final Color bg = dark ? Colors.white.withAlpha(20) : scheme.surface;
    final Color border = dark ? Colors.white.withAlpha(26) : scheme.outlineVariant;
    final Color fg = dark ? Colors.white.withAlpha(230) : scheme.onSurface;

    return Center(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: border),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(icon, size: 16, color: fg),
            const SizedBox(width: AppSpacing.x2),
            Text(
              label,
              style: AppTypography.caption.copyWith(
                color: fg,
                fontWeight: FontWeight.w700,
                letterSpacing: 1.2,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
