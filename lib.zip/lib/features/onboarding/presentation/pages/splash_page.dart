import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/router/app_router.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_spacing.dart';
import '../../../../core/theme/app_typography.dart';
import '../../../../core/widgets/tmz_button.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer(const Duration(milliseconds: 900), () {
      if (!mounted) return;
      context.go(AppRouter.onboardingPath);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.darkNavy,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(AppSpacing.x6),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              const Spacer(),
              Center(
                child: SvgPicture.asset(
                  'assets/icons/trumarkz_shield.svg',
                  height: 92,
                )
                    .animate()
                    .fadeIn(duration: 350.ms)
                    .scale(begin: const Offset(0.92, 0.92), end: const Offset(1, 1)),
              ),
              const SizedBox(height: AppSpacing.x4),
              Text(
                'TruMarkZ',
                textAlign: TextAlign.center,
                style: AppTypography.display1.copyWith(color: AppColors.offWhite),
              ).animate().fadeIn(delay: 120.ms, duration: 280.ms),
              const SizedBox(height: AppSpacing.x2),
              Text(
                'VERIFY · TRUST · TRANSFORM',
                textAlign: TextAlign.center,
                style: AppTypography.label.copyWith(
                  color: AppColors.offWhite.withAlpha(210),
                ),
              ).animate().fadeIn(delay: 220.ms, duration: 280.ms),
              const Spacer(),
              const TMZButton(label: 'Loading...', onPressed: null)
                  .animate()
                  .fadeIn(delay: 280.ms, duration: 280.ms),
              const SizedBox(height: AppSpacing.x2),
              Text(
                'By continuing, you agree to our security-first verification policy.',
                textAlign: TextAlign.center,
                style: AppTypography.caption.copyWith(
                  color: AppColors.offWhite.withAlpha(180),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
